# Archon Tech Access Builder 0.1.0

This is the first new build-engine delivery for the sewer contributions project. It is intentionally independent from the older 0.3.1 source bundle.

It contains importable VBA modules and Arabic installation / finance / testing documentation. It does not contain an ACCDB file. Run it only in a fresh blank ACCDB and use synthetic data until all operational tests and remaining features have been completed.
